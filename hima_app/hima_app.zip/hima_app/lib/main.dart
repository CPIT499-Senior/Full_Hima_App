import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart'; // Import the login screen

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hima App',
      initialRoute: '/', // Define the first screen
      routes: {
        '/': (context) => WelcomeScreen(),
        '/login': (context) => LoginScreen(), // Add Login Screen route
      },
    );
  }
}
